import java.util.ArrayList;

import javax.swing.JOptionPane;

public class surveyData {
	static String validateToken[][] = new String[100][3];
	static int rowIndex = 0;

	public static void main(String[] args) {
		int input = 0;
		while (input != 3) {
			String choices[] = { "Enter Survey Data", "View Survey Data", "Show Survey Stats", "Quit" };
			input = JOptionPane.showOptionDialog(null, "Select operation...", "Options", JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, choices, choices[1]);
			if (input == 0) {
				enterSurveyData();
				Schoolgrade();
				OperatingSys();
			} else if (input == 1) {
				viewSurveyData();
			} else if (input == 2) {
				showSurveyStatistics();
			} else if (input == 3) {
				exitSurvey();
			}
		}
	}

	public static void enterSurveyData() {
		String token = JOptionPane.showInputDialog(null, "What is your unique token " + "(ex: DFU)?", "Please Answer",
				JOptionPane.QUESTION_MESSAGE);
		while (token.length() != 3 || !token.matches("[a-zA-Z]*")) {
			if (token.length() != 3) {
				token = JOptionPane.showInputDialog(null,
						"INVALID INFORMATION. Token has more or less than 3 characters. "
								+ "\nWhat is your unique token (ex: DFU)?",
						"Please Answer", JOptionPane.QUESTION_MESSAGE);
			}
			if (!token.matches("[a-zA-Z]*")) {
				while (!token.matches("[a-zA-Z]*")) {
					token = JOptionPane.showInputDialog(null,
							"INVALID INFORMATION. Token accepts only letters. "
									+ "\nWhat is your unique token (ex: DFU)?",
							"Please Answer", JOptionPane.QUESTION_MESSAGE);
				}
			}
		}
		validateToken[rowIndex][0] = token;
	}

	public static void Schoolgrade() {
		String level;
		level = JOptionPane.showInputDialog(null,
				"What is your school level " + "(1-Freshman, 2-Sophomore, " + "3-Junior, or 4-Senior?)",
				"Please Answer", JOptionPane.QUESTION_MESSAGE);
		if (level == ("1")) {
			level = ("Freshman");
		} else if (level == ("2")) {
			level = ("Sophomore");
		} else if (level == ("3")) {
			level = ("Junior");
		} else if (level == ("4")) {
			level = ("Senior");
		} else {
			int level2 = Integer.parseInt(level);
			while (level2 > 4 || level2 < 1) {
				level = JOptionPane.showInputDialog(null,
						"INVALID RESPONSE! \nWhat is your school level "
								+ "(1-Freshman, 2-Sophomore, 3-Junior, or 4-Senior?)",
						"Please Answer", JOptionPane.QUESTION_MESSAGE);
				level2 = Integer.parseInt(level);
			}
			level = Integer.toString(level2);
		}
		validateToken[rowIndex][1] = level;
	}

	public static void OperatingSys() {
		String OS;
		OS = JOptionPane.showInputDialog(null,
				"What operating system do you use more often to complete school activities"
						+ "(1-Windows, 2-Mac, 3-Linux, 4-Chrome OS, 5-Other)",
				"Please Answer", JOptionPane.QUESTION_MESSAGE);
		if (OS == "1") {
			OS = ("Windows");
		} else if (OS == "2") {
			OS = ("Mac");
		} else if (OS == "3") {
			OS = ("Linux");
		} else if (OS == "4") {
			OS = ("Chrome");
		} else if (OS == "5") {
			OS = ("Other");
		} else {
			int OS2 = Integer.parseInt(OS);
			while (OS2 > 5 || OS2 < 1) {
				OS = JOptionPane.showInputDialog(null,
						"INVALID RESPONSE! \nWhat is your school level "
								+ "(1-Freshman, 2-Sophomore, 3-Junior, or 4-Senior?)",
						"Please Answer", JOptionPane.QUESTION_MESSAGE);
				OS2 = Integer.parseInt(OS);
			}
			OS = Integer.toString(OS2);
		}
		validateToken[rowIndex][2] = OS;
	}

	public static tokenExist(String token) {

	}

	public static void viewSurveyData() {
		System.out.println("Token" + "\t\t Level" + ("\t\t Operating System"));
		System.out.println("--------------------------------------------------");
		for (int i = 0; i < rowIndex; i++) {
			System.out.println(validateToken[i][0] + validateToken[i][1] + validateToken[i][2]);
		}

	}

	public static void showSurveyStatistics() {

	}

	public static void exitSurvey() {
		System.exit(0);
	}
}