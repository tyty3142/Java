import javax.swing.JPanel;

public class BookPanel extends JPanel{

	// ********************************
	// ATTRIBUTES
	// ********************************
	
	
	// ********************************
	// CONSTRUCTOR
	// ********************************
	
	public BookPanel() {

	}// end of constructor

	
	// ********************************
	// GETS/SETS
	// ********************************
	
	
	// ********************************
	// METHODS
	// ********************************
	
}// end of class
