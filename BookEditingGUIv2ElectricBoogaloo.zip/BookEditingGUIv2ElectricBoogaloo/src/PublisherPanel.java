import javax.swing.JPanel;

public class PublisherPanel extends JPanel{

	// ********************************
	// ATTRIBUTES
	// ********************************
	
	
	// ********************************
	// CONSTRUCTOR
	// ********************************
	
	public PublisherPanel(){
		
	}// end of constructor
	
	// ********************************
	// GETS/SETS
	// ********************************
	
	
	// ********************************
	// METHODS
	// ********************************
	
	
} // end of class
